Deep Learning for Natural Language Processing
=============================================

README
------

Welcome to Deep Learning for Natural Language Processing!

Your package contains:

1. README (this file)
	README.txt
2. The Ebook:
	deep_learning_for_nlp.pdf
3. Code Recipes:
	code/

The code directory provides access to all of the data and code examples used in the book.

Any questions at all, contact me direction via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.
