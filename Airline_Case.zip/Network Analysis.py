
# coding: utf-8

# ## Network Analysis
# 
# A graph **G = (V, E)**  consists of a set of **nodes** V ( or vertices, points)  and a set of **edges**  E ( links, lines) which illustrate how the nodes in the network are interacting with each other. Edges can be **directed** or ** undirected**. The number of nodes **N** is often called the **size** of the network and  states the number of objects in the model. 
# 
# Each node or edge can hold different attributes. Edges attributes, in the case of numerical attributes, are called weights. An graph with weighted edges is called an **weighted graph**.
# 
# A first measurement for a node in the graph is the so called **degree**, which stands for the number of edges it has to other nodes, denoted by *k*.  One can also might ask what is the average degree in the network? 
# 
# But wait a second... if the degree is the number of edges it has to other nodes, don't we have to distinguish between directed and undirected edges to calculate the degree? Indeed, we need to distiguish between the **In-degree** and the **Out-degree** of a node, simply measuring how many edges are leaving a node and how many edges are coming in. This of cource depends on if the graph is direted or not. In the case of an undirected graph we can calculate the **average degree** by the following formular:

# $$ (k) = \frac{1}{N} \sum_{i = 1}^N k_i = \frac{2E}{N}$$
# 
# Similar this can be done seperatly for the in- and out-degree:
# 
# $$ (k^{in}) = \frac{1}{N} \sum_{i = 1}^N k^{in}_i =(k^{out}) = \frac{1}{N} \sum_{i = 1}^N k^{out}_i =  \frac{E}{V}$$
# 
# because $$k_i = k^{out}_i  + k^{in}_i  $$

# ### What are the formats of network dataset?
# 
# Below are some of the most commonly used formats across the industry.
# 
# * CSV
# * GML
# * Pajek Net
# * Graph ML
# * GEXF (Graph Exchange XML Format - from Gephi)
# 

# ### Some sources for downloading openly available network datasets
# 
# https://snap.stanford.edu/data/
# 
# https://networkdata.ics.uci.edu/resources.php
# 
# http://konect.uni-koblenz.de/
# 
# http://sonetlab.fbk.eu/data/social_networks_of_wikipedia/
# 
# https://github.com/gephi/gephi/wiki/Datasets
# 
# 

# 
# We use networkx package in python for our analysis. This package provides lots and lots of API to read from various 
# formats and at the same time write output to different formats. What this means is that you can read data in one of the above formats and write to completely different format of your choice.
# 

# In[24]:


import networkx as nx
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# ### Reading data from various file formats

# #### CSV / TXT format (Edge List)

# In[25]:


gph = nx.read_edgelist('datasets/airline.txt',create_using=nx.Graph(),nodetype=int)
print(nx.info(gph))


# In[26]:


print(nx.info(gph))
print(nx.number_of_nodes(gph))
print(nx.number_of_edges(gph))
print(nx.is_directed(gph))


# In[27]:


import os
os.getcwd()
os.chdir("C:\\Users\\Jitendra\Desktop\\Tutorial-02")


# In[28]:


spring_pos=nx.spring_layout(gph)


# In[29]:


plt.axis("off")
nx.draw_networkx(gph,pos=spring_pos,with_lables=False,node_size = 35)


# #### Network Plotting

# In[11]:


nx.draw(gph)
plt.show()


# In[11]:


karate = nx.read_pajek('datasets/karate.paj')
nx.draw(karate)
plt.show()


# In[12]:


football = nx.read_pajek('datasets/football.net')
nx.draw(football)
plt.show()


# In[13]:


nx.draw_circular(karate)
plt.show()


# In[14]:


nx.draw_spectral(karate)
plt.show()


# In[15]:


nx.draw_spring(karate)
plt.show()


# #### Degrees and Degree Distribution

# In[16]:


deg = dict(nx.degree(karate))
deg


# In[17]:


deg.values()


# In[18]:


set(deg.values())


# In[19]:


def plot_deg_dist(g):
    all_deg = list(dict(nx.degree(karate)).values())
    unique_deg = list(set(all_deg))
    
    count_deg = []
    for i in unique_deg:
        x = all_deg.count(i)
        count_deg.append(x)
    
    plt.plot(unique_deg, count_deg, 'yo-')
    plt.xlabel('Degrees')
    plt.ylabel('Number of Nodes')
    plt.title('Degree Distribution of Karate Network')
    plt.show()


# In[20]:


plot_deg_dist(karate)


# #### Density

# Density = Number of egges present / Total number of possible edges

# In[21]:


test1 = nx.complete_graph(10)
nx.density(test1)


# In[22]:


test2 = nx.Graph()
test2.add_nodes_from([1,2,3,4])
nx.density(test2)


# In[23]:


nx.density(karate)


# #### Diameter

# Shortest Path between two extreme nodes

# In[24]:


nx.diameter(karate)

