

import networkx as nx
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# ### Reading data from various file formats

# #### CSV / TXT format (Edge List)




gph = nx.read_edgelist('datasets/airline.txt',create_using=nx.Graph(),nodetype=int)
print(nx.info(gph))



print(nx.info(gph))
print(nx.number_of_nodes(gph))
print(nx.number_of_edges(gph))
print(nx.is_directed(gph))




import os
os.getcwd()
os.chdir("C:\\Users\\Jitendra\Desktop\\Tutorial-02")




spring_pos=nx.spring_layout(gph)




plt.axis("off")
nx.draw_networkx(gph,pos=spring_pos,with_lables=False,node_size = 35)


# #### Network Plotting

# In[11]:


nx.draw(gph)
plt.show()



deg = dict(nx.degree(gph))
deg




deg.values()




set(deg.values())


# In[19]:


def plot_deg_dist(g):
    all_deg = list(dict(nx.degree(gph)).values())
    unique_deg = list(set(all_deg))
    
    count_deg = []
    for i in unique_deg:
        x = all_deg.count(i)
        count_deg.append(x)
    
    plt.plot(unique_deg, count_deg, 'yo-')
    plt.xlabel('Degrees')
    plt.ylabel('Number of Nodes')
    plt.title('Degree Distribution of Airline Passenger Data')
    plt.show()


# In[20]:


plot_deg_dist(karate)


# #### Density

# Density = Number of egges present / Total number of possible edges

# In[21]:


test1 = nx.complete_graph(10)
nx.density(test1)


# In[22]:


test2 = nx.Graph()
test2.add_nodes_from([1,2,3,4])
nx.density(test2)


# In[23]:


nx.density(gph)


# #### Diameter

# Shortest Path between two extreme nodes

# In[24]:


nx.diameter(karate)

